from django.contrib import admin
from .models import Product, Score

admin.site.register(Product)
admin.site.register(Score)
# Register your models here.
