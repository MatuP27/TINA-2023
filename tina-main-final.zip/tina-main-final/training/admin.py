from django.contrib import admin
from .models import TrainedProduct, TrainedProductPicture

admin.site.register(TrainedProduct)
admin.site.register(TrainedProductPicture)

# Register your models here.
