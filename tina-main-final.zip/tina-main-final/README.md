# tina
Cook bot API. Use IA for cooking. Take pictures with your phone so you can know if product is done


# Documentación
Aquí incorporaremos toda la documentación necesaria para unir las APPS, la API y conectar con el robot cocinero




# First steps

git clone git@github.com:paxapos/tina.git

pip install -r requirements.txt 

copy /tina/settings.py.copy to /tina/settings.py and change SECRET_KEY 

test that is correct working
python manage.py runserver



# Imagenes de entrenamienmto

https://github.com/paxapos/tina/files/9229521/Milanesas.zip
